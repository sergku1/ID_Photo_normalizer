# calc_photo
A program for normalizing images of passports or ID cards and collecting information from them into a structure of named (first name-last name) folders - data storage structure 
